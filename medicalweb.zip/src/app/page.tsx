import React from 'react'
import HomePage from './home/page'

const Home = () => {
  return (
    <div className='min-h-screen flex flex-col'>
      <HomePage />
    </div>

  )
}

export default Home
