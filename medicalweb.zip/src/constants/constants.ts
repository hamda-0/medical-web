export const appName='HealthCare'
export const appVersion='1.0.0'
export const doubleq=`&#34;`
export const singleq=`&#39;`
